package com.example.pruba

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        var boton1: Button?=null;
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        boton1=findViewById(R.id.button);
        boton1?.setOnClickListener{
            Log.i("mensaje","Hola Mundo");
            startActivity(Intent(this,MainActivity2::class.java))
        };
    }
}