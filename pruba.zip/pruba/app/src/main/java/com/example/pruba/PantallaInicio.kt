package com.example.pruba

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PantallaInicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla_inicio)
    }
}